package sample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class EmpDAO {

		//DB 연결 관련 변수 선언
		String driverName = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
		String user = "hr";
		String pass = "1234";
		
		private EmpDAO() throws Exception {
			//장치를 찾는 프로그램
			//1. 드라이버 로딩 (에러잡을거면 try catch로 안잡을거면 throws로)
			// 단 한번만 (메모리에 올라온다)실행해야한다 -> 그래서 private
			Class.forName(driverName);
			System.out.println("생성자 한번");
		}
		
		//외부에서 부를 수 있는 변수
		static EmpDAO dao = null;
		public static EmpDAO getInstance() throws Exception {
			if(dao==null) dao = new EmpDAO();
			return dao;
		} //dao라는 초기값이 null이여서 두번째로 부르면 첫번재 불렀던 값이 불려진다.
		
		public ArrayList<EmpVO> selectEmp() throws Exception {
			//예외처리가 되든 오류가 생기든 전송된 객체를 닫아 줘야 하기때문에 close는 항상 있어야 한다.
			//->그래서 이걸 항상 사용하려면 finally로 묶어줘야하고 fianlly를 사용하려면 try catch중 try만 사용해야한다.
			//지역변수는 {}안에 선언된 변수는 그 안에서만 사용될 수 있기때문에 con와 ps 변수 선언을 try finally 구문앞에 지정한다
			//기본값을 null로 초기화 해야 finally에 있는 ps와 con에 에러를 막을 수 있다.
			Connection con = null;
			PreparedStatement ps = null;
			try {				
			//2. 연결객체 얻어오기
			con = DriverManager.getConnection(url, user, pass);
			//3. sql 문장 만들기
			String sql = "SELECT * FROM employee";
			//4. 전송객체 얻어오기
			ps = con.prepareStatement(sql);
			//5. 전송(excuteUpate() / executeQuery())
			ResultSet rs = ps.executeQuery();
		// ResultSet -> 자바에서 select 등의 조회 쿼리문을 실행하면 커멘드 창이 아니므로 바로 정보를 가져오기 어렵고,
		// 				이용하기에도 어려움이 있다. 이때 사용하게 되는 클래스가 ResultSet 클래스이다.
		// executeQuery() 메서드를 이용할때 결과를 ResultSet으로 	받는다.
		// ex )) ResultSet rs = stmt.executeQuery("select * from score");
	
			ArrayList<EmpVO> list = new ArrayList<EmpVO>();
			//밑에 반복문을 저장하기 위해서 배열을 써야하는데 배열은 몇개인지를 알아야 하기때문에
			//동적인 ArrayList 변수를 바깥에 지정하여 사용한다.
			while(rs.next()) {
				EmpVO vo = new EmpVO();
				vo.setEno(rs.getInt("ENO"));
				vo.setEname(rs.getString("ENAME"));
				vo.setJob(rs.getString("JOB"));
				vo.setManager(rs.getInt("MANAGER"));
				list.add(vo);
			}
			return list;
			//다만든 리스트를 화면으로 보냄
			//public void 는 return하지 않기때문에 void자리에 ArrayList<EmpVO>를 쓴다
			} finally {
			
			//6. 닫기 (자식먼저 닫고, 본체 닫는다)
			ps.close();
			con.close();
			}
		}
		
		
		
		
		public void insertEmp(EmpVO vo) throws Exception {
			
			Connection conn = null;
			PreparedStatement pstmt = null;
			try {				
			//2. 연결객체 얻어오기
			conn = DriverManager.getConnection(url, user, pass);
			//3. sql 문장 만들기
			String sql = "INSERT INTO employee(eno, ename, salary, job) VALUES(?,?,?,?)";
			//4. 전송객체 얻어오기
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, vo.getEno());
			pstmt.setString(2, vo.getEname());
			pstmt.setInt(3, vo.getSalary());
			pstmt.setString(4, vo.getJob());
			
			//5. 전송(excuteUpate() / executeQuery())
			pstmt.executeUpdate();
			
			} finally {
			
			//6. 닫기 (자식먼저 닫고, 본체 닫는다) => 가장 작은 아이부터 close해야한다
			pstmt.close();
			conn.close();
			}
		}
		
	/*	정성님이 알려준 방식
	  	public ArrayList<EmpVO> viewEmp(String eno) throws Exception {
			Connection con = null;
			PreparedStatement ps = null;
			try {				
			//2. 연결객체 얻어오기
			con = DriverManager.getConnection(url, user, pass);
			//3. sql 문장 만들기
			String sql = "SELECT * FROM employee Where eno=?";//eno가 문자형이니까 
			//4. 전송객체 얻어오기
			ps = con.prepareStatement(sql);
			ps.setInt(1, Integer.parseInt(eno));
			
			//5. 전송(excuteUpate() / executeQuery())
			ResultSet rs = ps.executeQuery();
	
			ArrayList<EmpVO> list = new ArrayList<EmpVO>();

			while(rs.next()) {
				EmpVO vo = new EmpVO();
				vo.setEno(rs.getInt("ENO"));
				vo.setJob(rs.getString("JOB"));
				vo.setEname(rs.getString("ENAME"));
				vo.setManager(rs.getInt("MANAGER"));
				vo.setHiredate(rs.getString("HIREDATE"));
				vo.setSalary(rs.getInt("SALARY"));
				vo.setCommission(rs.getInt("COMMISSION"));
				vo.setDno(rs.getInt("DNO"));
				list.add(vo);
			}
			return list;

			} finally {
			
			//6. 닫기 (자식먼저 닫고, 본체 닫는다)
			ps.close();
			con.close();
			}
		}	*/
		
		//강사님과 함께 푼 문제
				//넣을 자료형을 맞춰준다 =>EmpVO
		public EmpVO viewEmp(String eno)throws Exception{
			// JDBC 절차 작성 
			Connection conn = null;
			PreparedStatement pstmt = null;		
		try {
			// 2. 연결객체 얻어오기		
			conn = DriverManager.getConnection(url,user,pass);
			// 3. sql 만들기 		
			String sql = "SELECT * FROM employee WHERE eno=?";
			// 4. 전송객체 
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, Integer.parseInt(eno));
			// 5. 전송 ( int executeUpdate() / ResultSet executeQuery() )
			ResultSet rs = pstmt.executeQuery();
			// 6. 결과처리
			EmpVO vo = new EmpVO();
			if( rs.next() ) {
				vo.setEno( rs.getInt("ENO"));
				vo.setEname(rs.getString("Ename"));
				vo.setJob(rs.getString("Job"));
				vo.setManager(rs.getInt("Manager"));
				vo.setHiredate(rs.getString("Hiredate"));
				vo.setSalary(rs.getInt("Salary"));
				vo.setCommission(rs.getInt("Commission"));
				vo.setDno(rs.getInt("Dno"));
			}
				
			return vo;
			
		} finally {
			// 7. 닫기 : 가장 작은 아이부터 close해야한다.
			pstmt.close();
			conn.close();
		}
		}
		
	
		//삭제버튼을 클릭하면 회원정보가 삭제됨
				//return되는 아이의 자료형인 int값을 void자리에 넣어줌
		public int deleteEmp(String eno) throws Exception{
			Connection con = null;
			PreparedStatement ps = null;
			
			try {
				//2.연결객체 가져오기
				con = DriverManager.getConnection(url, user,pass);
				//3.sql문장 작성
				//사번이 넘어오는 걸로 나는 삭제하겠다
				//delte from 사이에 *는 넣지 말아라
			    String sql = "DELETE FROM employee WHERE eno=?";	
				//4.sql문장을 전송객체 얻어오기
				ps = con.prepareStatement(sql);
				ps.setInt(1, Integer.parseInt(eno));
				
				//5.전송
				//필요없으면 던져주는 값을 안받아도 됨 ps.executeUpdate();
				int result = ps.executeUpdate();
				return result;
				// 변수가 한번사용되고 한줄로나타내면  => return ps.executeUpdate();
			}finally {
				//7.연결객체 닫기
				ps.close();
				con.close();
			
			}
		}
		
		public void modifyEmp(EmpVO vo) throws Exception {
			Connection conn = null;
			PreparedStatement pstmt = null;		
		try {
			// 2. 연결객체 얻어오기		
			conn = DriverManager.getConnection(url,user,pass);
			
			// 3. sql 문장 만들기
			String sql = "UPDATE employee SET  "
					+ " ename=?, "
					+ " job=?, "
					+ " salary=? " // 나머지도 처리
					+ " WHERE eno=?";
			// UPDATE employee SET ename='홍길순', job='개발자', salary=5000
			//		WHERE eno=7799
			
			// 4. 전송객체 얻어오기
			pstmt = conn.prepareStatement(sql);		
			pstmt.setString(1, vo.getEname());		
			pstmt.setString(2, vo.getJob());		
			pstmt.setInt(3, vo.getSalary());		
			pstmt.setInt(4, vo.getEno());
			
			
			// 5. 전송 ( executeUpdate() / executeQuery() )
			pstmt.executeUpdate();

		} finally {
			// 7. 닫기 : 가장 작은 아이부터 close해야한다.
			pstmt.close();
			conn.close();
		}

	}
		
		
		// dao.login을 만들어서 (user,pass)를 employee 테이블에 user=ename/pass=eno로 나와야 로그인이 되도록
}